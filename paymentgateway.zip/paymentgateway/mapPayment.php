<?php
if($_POST['pg'] == "CashFree"){
    header("Location: https://speedrent.in/pavanDemo/Cashfree/createOrder.php?amount={$_POST['amount']}&phone={$_POST['phone']}");
}
else{
    header("Location: https://speedrent.in/pavanDemo/Razorpay/getOrderId.php?amount={$_POST['amount']}&phone={$_POST['phone']}");
}


?>