<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
require('Razorpay.php');
use Razorpay\Api\Api;
$api = new Api("merchant Id", "merchant Key");
$orderData = [
  'receipt'         => strval(rand(111111,999999)),
  'amount'          => $_GET['amount']*100, 
  'currency'        => 'INR'
];
$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder['id'];

$showRecord = mysqli_query( $conn, "INSERT INTO `testPayments`( `transactionId`, `phone`, `amount`, `status`, `created`) VALUES ('{$razorpayOrderId}','{$_GET['phone']}','{$_GET['amount']}','PENDING','{$date}')");
   
    $return[ 'message' ] =  $razorpayOrderId;
if ( $showRecord ) {

    $return[ 'error' ] = false;
    

} else {
    $return[ 'error' ] = true;
    $return[ 'message' ] = 'server down, Please come back later.';
}
$newamount = $_GET['amount']*100;
 header("Location: https://speedrent.in/pavanDemo/Razorpay/webcheckout.php?session_id={$razorpayOrderId}&amount={$newamount}");

mysqli_close( $conn );


echo json_encode( $return );

?>

