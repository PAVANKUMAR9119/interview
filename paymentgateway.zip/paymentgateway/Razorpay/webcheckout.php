<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<button id="rzp-button1">Pay</button>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var options = {
   "key": "merchant ID", // Enter the Key ID generated from the Dashboard
    "amount": <?php echo $_GET['amount']?>, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Speedrent bikes ",
    "description": "Bike booking payment",
    "image": "https://speedrent.in/adminapp/uploads/speed.png",
    "order_id": "<?php $_GET['session_id']?>",
    //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
    "redirect": true,
    "callback_url": "https://speedrent.in/pavanDemo/Cashfree/paymentDone.html",
    "prefill": {
        "name": "Pavankumar",
        "email": "pavankumarkbletters@gmail.com",
        "contact": "8660364212"
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    },
};
var rzp1 = new Razorpay(options);
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>










