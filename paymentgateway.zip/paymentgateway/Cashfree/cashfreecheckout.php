
<html>
<head>
   <title>cashfree checkout</title>
   <script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
</head>
<body>
  <!--<h2> Methods to call a JavaScript function on page load. </h2>
  <h4> Call the JavaScript function on page load by using <i>window.onload</i> event in the JavaScript. </h4>-->
   <div id="message"> </div>
   <script type="text/javascript">
      window.onload = simpleFunction(  ); // call function with parameters on page load
      function simpleFunction( 
          ) {
              const cashfree = Cashfree({
    mode:"production" //or production
});
//console.log(<?php echo $_GET['session_id']?>);
let checkoutOptions = {
    paymentSessionId: "<?php echo $_GET['session_id']?>",
    redirectTarget: "_self" //optional (_self or _blank)
}

cashfree.checkout(checkoutOptions)
        // alert(" The sum of num1 and num2 is " + ( num1 + num2 ) );
       //  message.innerHTML = "Showing the message after alert box."
      }
   </script>
</body>
</html>