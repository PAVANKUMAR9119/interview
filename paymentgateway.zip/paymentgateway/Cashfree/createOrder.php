<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
require 'db.php';
date_default_timezone_set("Asia/Calcutta");   
$date =  date('d-m-Y H:i:s');
$recieptId = "P".strval(rand(1111111111,9999999999));
$amount = floatval($_GET['amount']+".00");
$phone = $_GET['phone'];
$callbackUrl = "https://speedrent.in/pavanDemo/Cashfree/paymentDone.html";
$url = 'https://api.cashfree.com/pg/orders';
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt( $curl, CURLOPT_HTTPHEADER, array("Accept: application/json",
    "Content-Type: application/json",
    "x-api-version: 2022-09-01",
    "x-client-id: *****************************",
     "x-client-secret: ************************************"));
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, '{
   "order_id": "'.$recieptId.'",
   "order_amount": "'.$amount.'",
   "order_currency": "INR",
   "order_note": "Additional order info",
   "customer_details": {
   "customer_id": "12345",
    "customer_name": "PAVANKUMAR K B",

    "customer_phone": "'.$phone.'"
  }
  ,
  "order_meta": { 
    "return_url": "'.$callbackUrl.'"
   
  }
}');
$result = curl_exec($curl);
curl_close($curl);
$result1 = json_decode($result, true);
$session_code = $result1["payment_session_id"];
$return[ 'error' ] = false;
$return[ 'message' ] = '';
$showRecord = mysqli_query( $conn, "INSERT INTO `testPayments`( `transactionId`, `phone`, `amount`, `status`, `created`) VALUES ('{$recieptId}','{$phone}','{$amount}','PENDING','{$date}')");

if ( $showRecord ) {
   
    
    header("Location: https://speedrent.in/pavanDemo/Cashfree/cashfreecheckout.php?session_id={$session_code}");
    
} else {
    $return[ 'error' ] = true;
    $return[ 'message' ] = 'server down, Please come back later.';
}
mysqli_close( $conn );


?>