<?php

$servername = 'localhost';
$database = '*******************';
$username = '*******************';
$password = '***************';
$conn = new mysqli( $servername, $username, $password, $database );
?>