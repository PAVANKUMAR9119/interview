<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
$obj=json_decode(file_get_contents("php://input"), true);
$obj3=$obj['data']['payment']['payment_status'];
$obj1=$obj['data']['order']['order_id'];
$obj2=$obj['data']['payment']['bank_reference'];
if($obj3 == "SUCCESS"){
    $updateData = mysqli_query( $conn, "UPDATE `testPayments` SET `status` = '{$obj2}' where `transactionId` = '{$obj1}'" );
if ( $updateData ) {
    $return[ 'error' ] = false;
    $return[ 'message' ] = 'payment data updated successfully..!';
} else {
    $return[ 'error' ] = true;
    $return[ 'message' ] = 'server down, Please come back later.';
}
echo json_encode( $return );
}
mysqli_close( $conn );
?>
