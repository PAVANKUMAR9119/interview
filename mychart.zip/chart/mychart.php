<?php
$letters = ["A","B","C","D","E","F","G","H","I","J"] ;
$number = rand(1,9);
$letter = $letters[$number];
$response = [
    ["letter" => $letter,
    "number" => $number]
    ];
echo json_encode($response);
?>